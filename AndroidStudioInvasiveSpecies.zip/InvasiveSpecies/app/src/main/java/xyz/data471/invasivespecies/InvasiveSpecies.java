package xyz.data471.invasivespecies;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
// Used https://developer.android.com/guide/webapps/webview.html documentation


public class InvasiveSpecies extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invasive_species);
        WebView invasiveSpec = (WebView) findViewById(R.id.webview);
        invasiveSpec.setWebViewClient(new WebViewClient());
        WebSettings appSettings = invasiveSpec.getSettings();
        final Activity activity = this;
        //        Error handling idea from https://developer.android.com/reference/android/webkit/WebView.html
        invasiveSpec.setWebViewClient(new WebViewClient() {
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(activity, "Oh no! It appears you have no internet connection! Please close this app and try again.", Toast.LENGTH_LONG).show();
                setContentView(R.layout.activity_invasive_species);
            }
        });

        appSettings.setJavaScriptEnabled(true);
        invasiveSpec.loadUrl("http://dataentry:EnterPassword1.@@www.data471.xyz");

    }
}
